"""Eastbank Technical College: editable campus source and a separate static GLB.

Authoring axes: Blender Z-up, metres. Runtime: glTF Y-up, metres.
This script is packed in the .blend; it never edits the application's code.
"""
import bpy, math, random, json, os, sys
from pathlib import Path
from mathutils import Vector, Matrix
from collections import defaultdict

REPO = Path(os.environ.get('EASTBANK_REPO', str(Path.cwd()))).resolve()
OUT = Path(__file__).resolve().parent
ROOT = OUT
SOURCE = REPO / 'source/levels/eastbank-school.blend'
RAW_GLB = OUT / 'eastbank-school-raw.glb'
random.seed(8417)
PI = math.pi
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = 1
COLS = {}
for name in ['01_Site','02_Academic','03_Library','04_Assembly','05_Sports','06_Canteen','07_Workshop','08_StreetProps','09_Landscape','10_Collision','11_GrindPaths','12_Markers','13_Lighting','14_Runtime']:
    c=bpy.data.collections.new(name);scene.collection.children.link(c);COLS[name]=c

mat_names = {
 'concrete':'Concrete | trowelled aggregate / 4m repeat',
 'precast':'Concrete | warm precast / 4m repeat',
 'brick':'Brick | fired clay retaining walls / 1.6m',
 'wood':'Timber | oiled hardwood / 2m',
 'soil':'Landscape | dry loam / 4m',
 'enamel':'Enamel | aged petrol blue',
 'tile':'Tile | warm porcelain',
 'steel':'Steel | brushed galvanized coping',
 'dark':'Steel | graphite powdercoat',
 'joint':'Construction | recessed sealant',
 'leaf':'Foliage | opaque eucalyptus leaves',
 'bark':'Bark | silver-grey eucalyptus',
 'asphalt':'Asphalt | service road',
 'paint':'Paint | warm road markings',
}
with bpy.data.libraries.load(str(REPO/'source/skatepark.blend'),link=False) as (src,dst):
    dst.materials=list(mat_names.values())
    dst.objects=[]
M={key:bpy.data.materials.get(name) for key,name in mat_names.items()}
TREE_SOURCE=[o for o in dst.objects if o]
for o in TREE_SOURCE:
    o.hide_render=True

def material(name,color,rough=.7,metal=0):
    m=bpy.data.materials.new(name);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
    m.diffuse_color=(*color,1);return m
M['glass']=material('School | opaque blue-grey architectural glazing',(.075,.16,.18),.19,.32)
M['cream']=material('School | cream enamel wayfinding',(.88,.83,.68),.52)
M['terra']=material('School | oxidised red enamel',(.36,.095,.055),.65)
M['court']=M['concrete'].copy();M['court'].name='School | worn petrol court / textured mineral finish'
# Colour the surface via the source material's documented vertex colour input.
M['yellow']=material('School | ochre line markings',(.77,.48,.13),.76)
M['rubber']=material('School | rubber and cable sheaths',(.036,.043,.047),.88)
M['collision']=material('Collision | inspection only',(.18,.7,.25),1)
SOURCE_VISIBLE=[];COLLIDERS=[];PATHS=[];MARKERS=[]
ZONE_KEYS={1:'01_Site',2:'02_Academic',3:'03_Library',4:'04_Assembly',5:'05_Sports',6:'06_Canteen',7:'07_Workshop',8:'08_StreetProps',9:'09_Landscape'}

def uv_color(mesh,key,color=None):
    repeat={'brick':1.6,'wood':2,'tile':1.2}.get(key,4)
    uv=mesh.uv_layers.new(name='UVMap')
    for p in mesh.polygons:
        n=p.normal;ax=max(range(3),key=lambda i:abs(n[i]));axes=[i for i in range(3) if i!=ax]
        for li in p.loop_indices:
            co=mesh.vertices[mesh.loops[li].vertex_index].co
            uv.data[li].uv=(co[axes[0]]/repeat,co[axes[1]]/repeat)
    col=mesh.color_attributes.new(name='Surface_Tint',type='FLOAT_COLOR',domain='CORNER')
    c=color or (1,1,1,1)
    col.data.foreach_set('color',list(c)*len(mesh.loops))
    mesh.color_attributes.active_color=col

def mesh_obj(name,verts,faces,key,zone=1,smooth=False,color=None,collision=False):
    me=bpy.data.meshes.new(name+'_Geometry');me.from_pydata(verts,[],faces);me.update()
    me.materials.append(M[key]);uv_color(me,key,color)
    o=bpy.data.objects.new(name,me);COLS[ZONE_KEYS[zone]].objects.link(o)
    for p in me.polygons:p.use_smooth=smooth
    o['role']='environment';o['area']=ZONE_KEYS[zone][3:];o['feature_id']=name
    SOURCE_VISIBLE.append(o)
    if collision:collider(o)
    return o

def collider(o,name=None):
    c=o.copy();c.data=o.data.copy();c.name='COL_'+(name or o.name)
    c.modifiers.clear();c.data.materials.clear();c.data.materials.append(M['collision'])
    COLS['10_Collision'].objects.link(c);c.hide_render=True;c.display_type='WIRE'
    c['role']='collision';c['source_feature']=o.name;c['area']=o.get('area','Site')
    COLLIDERS.append(c);return c

def box(name,center,size,key='concrete',zone=1,bevel=.018,collision=False,color=None):
    x,y,z=center;a,b,c=[v/2 for v in size]
    v=[(x+sx*a,y+sy*b,z+sz*c) for sx,sy,sz in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
    f=[(3,2,1,0),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)]
    o=mesh_obj(name,v,f,key,zone,color=color,collision=collision)
    if bevel:
        mod=o.modifiers.new('Rounded manufactured edges','BEVEL');mod.width=min(bevel,min(size)*.22);mod.segments=3
        mod.affect='EDGES'
        n=o.modifiers.new('Planar face normals','WEIGHTED_NORMAL');n.keep_sharp=True;n.weight=50
    return o

def tube(name,points,radius,key='steel',zone=8,sides=16,closed=False,collision=False):
    pts=[Vector(p) for p in points];v=[];f=[]
    for i,p in enumerate(pts):
        tangent=pts[(i+1)%len(pts)]-pts[(i-1)%len(pts)] if closed else pts[min(i+1,len(pts)-1)]-pts[max(0,i-1)]
        tangent.normalize();ref=Vector((0,0,1)) if abs(tangent.z)<.92 else Vector((1,0,0))
        u=tangent.cross(ref).normalized();w=tangent.cross(u).normalized()
        for j in range(sides):v.append(tuple(p+radius*(math.cos(j*2*PI/sides)*u+math.sin(j*2*PI/sides)*w)))
    for i in range(len(pts) if closed else len(pts)-1):
        k=(i+1)%len(pts)
        for j in range(sides):f.append((i*sides+j,i*sides+(j+1)%sides,k*sides+(j+1)%sides,k*sides+j))
    if not closed:f += [tuple(range(sides-1,-1,-1)),tuple((len(pts)-1)*sides+j for j in range(sides))]
    return mesh_obj(name,v,f,key,zone,smooth=True,collision=collision)

def marker(name,pos=(0,0,0),props=None):
    o=bpy.data.objects.new(name,None);o.empty_display_type='ARROWS';o.empty_display_size=.5;o.location=pos
    COLS['12_Markers'].objects.link(o)
    for k,v in (props or {}).items():o[k]=v
    MARKERS.append(o);return o

def grind(name,pts,kind='rail',radius=.035,closed=False,feature=None):
    o=bpy.data.objects.new('PATH_'+name,None);o.empty_display_type='PLAIN_AXES';o.empty_display_size=.18
    COLS['11_GrindPaths'].objects.link(o)
    o['role']='grind_path';o['kind']=kind;o['closed']=closed;o['radius']=radius
    o['points']=[v for x,y,z in pts for v in (x,z,-y)]
    o['coordinate_system']='local glTF Y-up metres';o['source_feature']=feature or name
    PATHS.append(o);return o

def rail(name,a,b,zone=8,radius=.033,supports=3,base_z=0):
    a,b=Vector(a),Vector(b);tube(name+'_TopRail',[a,b],radius,'steel',zone,sides=20,collision=True)
    grind(name,[tuple(a),tuple(b)],radius=radius,feature=name+'_TopRail')
    for i in range(supports):
        t=(i+.18)/(supports-.64);t=min(.94,max(.06,t));p=a.lerp(b,t)
        z=base_z(t) if callable(base_z) else base_z
        tube(name+'_Support_%02d'%i,[(p.x,p.y,z+.025),(p.x,p.y,p.z)],.025,'steel',zone)
        box(name+'_Footplate_%02d'%i,(p.x,p.y,z+.018),(.14,.14,.036),'steel',zone,bevel=.005)
        for dx,dy in [(-.045,-.045),(.045,.045)]:
            tube(name+'_Bolt_%02d_%s'%(i,dx),[(p.x+dx,p.y+dy,z+.035),(p.x+dx,p.y+dy,z+.045)],.009,'dark',zone,sides=8)

def ledge(name,center,size,zone=8,key='precast',grind_side='both'):
    o=box(name,center,size,key,zone,.022,True)
    x,y,z=center;w,d,h=size
    for sy in ([-1,1] if grind_side=='both' else [-1]):
        a=(x-w/2+.035,y+sy*(d/2-.025),z+h/2+.006);b=(x+w/2-.035,a[1],a[2])
        tube(name+'_Edge_%s'%sy,[a,b],.012,'steel',zone,sides=12);grind(name+'_Edge_%s'%sy,[a,b],'ledge',.012,feature=o.name)
    return o

def stairs(name,x,y,width,steps,rise=.18,tread=.36,z0=0,zone=8,axis='y',direction=1,handrails=True):
    # y (or x) is the foot of the flight; a level landing starts after the last tread.
    for i in range(steps):
        a=y+direction*(i+.5)*tread
        center=(x,a,z0+(i+1)*rise/2) if axis=='y' else (a,x,z0+(i+1)*rise/2)
        size=(width,tread,(i+1)*rise) if axis=='y' else (tread,width,(i+1)*rise)
        box(name+'_Tread_%02d'%(i+1),center,size,'precast',zone,.009,True)
        # Thin inset anti-slip nosing, geometry rather than a painted placeholder.
        edgea=y+direction*(i*tread+.035)
        cen=(x,edgea,z0+(i+1)*rise+.002) if axis=='y' else (edgea,x,z0+(i+1)*rise+.002)
        siz=(width-.1,.028,.004) if axis=='y' else (.028,width-.1,.004)
        box(name+'_Nosing_%02d'%i,cen,siz,'joint',zone,0)
    if handrails:
        for side in [-1,1]:
            lateral=x+side*(width/2-.18)
            p0=(lateral,y-direction*.35,z0+.88) if axis=='y' else (y-direction*.35,lateral,z0+.88)
            p1=(lateral,y+direction*(steps*tread+.5),z0+steps*rise+.88) if axis=='y' else (y+direction*(steps*tread+.5),lateral,z0+steps*rise+.88)
            def bz(t):
                along=t*(steps*tread+.85)-.35
                index=max(0,min(steps,math.floor(along/tread)+1))
                return z0+index*rise
            rail(name+'_Handrail_%s'%side,p0,p1,zone,supports=max(3,steps//3),base_z=bz)
    return y+direction*steps*tread,z0+steps*rise

def bank(name,foot,top,width,zone=8):
    a,b=Vector(foot),Vector(top);dx=b.x-a.x;dy=b.y-a.y;vdir=Vector((-dy,dx,0)).normalized()*width/2
    v=[tuple(a-vdir),tuple(a+vdir),tuple(b+vdir),tuple(b-vdir),tuple(Vector((a.x,a.y,min(a.z,b.z)-.1))-vdir),tuple(Vector((a.x,a.y,min(a.z,b.z)-.1))+vdir),tuple(Vector((b.x,b.y,min(a.z,b.z)-.1))+vdir),tuple(Vector((b.x,b.y,min(a.z,b.z)-.1))-vdir)]
    f=[(0,3,2,1),(4,5,6,7),(4,0,1,5),(5,1,2,6),(6,2,3,7),(7,3,0,4)]
    # Correct top face order: +Z for the skateable slope.
    f[0]=(0,3,2,1)
    return mesh_obj(name,v,f,'concrete',zone,collision=True)

def text(name,body,pos,size=.4,zone=8,normal='south',key='cream',extrude=.002):
    cu=bpy.data.curves.new(name+'_EditableTypography','FONT');cu.body=body;cu.size=size;cu.extrude=extrude;cu.bevel_depth=.0007;cu.align_x='CENTER'
    o=bpy.data.objects.new(name,cu);COLS[ZONE_KEYS[zone]].objects.link(o);o.location=pos
    if normal=='south':o.rotation_euler=(PI/2,0,0)
    elif normal=='west':o.rotation_euler=(PI/2,0,-PI/2)
    cu.materials.append(M[key]);o['role']='environment';o['area']=ZONE_KEYS[zone][3:];SOURCE_VISIBLE.append(o);return o

def bench(name,x,y,z=0,zone=8,axis='x',length=2.6):
    for i in range(5):
        cen=(x,y+(i-2)*.085,z+.46) if axis=='x' else (x+(i-2)*.085,y,z+.46)
        siz=(length,.074,.05) if axis=='x' else (.074,length,.05)
        box(name+'_SeatSlat_%02d'%i,cen,siz,'wood',zone,.007,True)
    for side in [-1,1]:
        p=(x+side*(length/2-.25),y,z+.23) if axis=='x' else (x,y+side*(length/2-.25),z+.23)
        box(name+'_Frame_%s'%side,p,(.07,.48,.46) if axis=='x' else (.48,.07,.46),'dark',zone,.01)
    grind(name,[(x-length/2,y-.21,z+.485),(x+length/2,y-.21,z+.485)] if axis=='x' else [(x-.21,y-length/2,z+.485),(x-.21,y+length/2,z+.485)],'ledge',.018,feature=name)

def joint_grid(name,x0,x1,y0,y1,z,zone=1,spacing=4):
    i=0;x=math.ceil(x0/spacing)*spacing
    while x<x1:
        box(name+'_Long_%02d'%i,(x,(y0+y1)/2,z),(.009,y1-y0,.002),'joint',zone,0);x+=spacing;i+=1
    y=math.ceil(y0/spacing)*spacing
    while y<y1:
        box(name+'_Cross_%02d'%i,((x0+x1)/2,y,z),(x1-x0,.009,.002),'joint',zone,0);y+=spacing;i+=1

print('Materials and authoring helpers ready',flush=True)

# SITE: a deliberate hierarchy of connected plazas and terraces. Cutouts preserve
# the sunken assembly floor and stormwater transition basin without hidden caps.
cutouts=[(-23,5,-1,17),(-59,-27,14,30)]
def subtract_rect(rect,cut):
    x0,x1,y0,y1=rect;a,b,c,d=cut
    l=max(x0,a);r=min(x1,b);lo=max(y0,c);hi=min(y1,d)
    if l>=r or lo>=hi:return [rect]
    result=[(x0,l,y0,y1),(r,x1,y0,y1),(l,r,y0,lo),(l,r,hi,y1)]
    return [q for q in result if q[1]-q[0]>.001 and q[3]-q[2]>.001]
for ix,x0 in enumerate(range(-66,66,6)):
    for iy,y0 in enumerate(range(-54,54,6)):
        rects=[(x0,x0+6,y0,y0+6)]
        for cut in cutouts:rects=[piece for q in rects for piece in subtract_rect(q,cut)]
        for k,(a,b,c,d) in enumerate(rects):
            tint=(random.uniform(.92,1.0),)*3+(1,)
            box('Campus_Slab_%02d_%02d_%02d'%(ix,iy,k),((a+b)/2,(c+d)/2,-.12),(b-a,d-c,.24),'concrete',1,.004,True,color=tint)
            # Visible joints stay on the shared boundaries, never across a hole.
            box('Campus_Joint_%02d_%02d_%02d'%(ix,iy,k),((a+b)/2,c+.008,.0015),(b-a,.012,.003),'joint',1,0)
box('Surrounding_Earth',(0,0,-3.7),(182,152,.8),'soil',1,0)
for name,center,size in [
 ('West',(-78.5,0,-.4),(25,152,.7)),('East',(78.5,0,-.4),(25,152,.7)),
 ('North',(0,65,-.4),(132,22,.7)),('South',(0,-65,-.4),(132,22,.7))]:
    box('Surrounding_Ground_'+name,center,size,'soil',1,0)
box('Dropoff_Road',(0,-64,-.06),(178,14,.1),'asphalt',1,.002,True)
box('North_Service_Road',(0,61,-.04),(172,9,.08),'asphalt',1,0,True)
box('East_Footpath',(70,0,-.01),(4,128,.16),'precast',1,.025,True)
box('South_Footpath',(0,-56.5,-.01),(132,5,.16),'precast',1,.025,True)
for x in range(-65,66,10):box('Road_Dash_%s'%x,(x,-64,.001),(4,.1,.004),'paint',1,0)
for x in [-44,-31,-18]:
    box('BusBay_Boundary_%s'%x,(x,-60.6,.005),(10.5,.12,.005),'yellow',1,0)
    text('BusBay_Label_%s'%x,'BUS', (x,-62,.008),1.25,1,normal='up',key='yellow',extrude=0)

# TWO-STOREY TEACHING WING: real modular masonry bays, shaded glazing,
# verandas, doors and roofs. The empty floor plates are usable future interiors.
box('Academic_GroundFloor',(43,18,1.34),(18,68,.2),'precast',2,.024,True)
box('Academic_UpperFloor',(43,18,5.25),(18.2,68.2,.24),'precast',2,.025,True)
box('Academic_RoofSlab',(43,18,9.1),(19.6,69.5,.28),'precast',2,.03)
box('Academic_EastWall',(51.8,18,5.25),(.35,68,7.62),'brick',2,.025,True)
for y in [-15.8,51.8]:box('Academic_EndWall_%s'%y,(43,y,5.25),(18,.35,7.62),'brick',2,.025,True)
box('Academic_Veranda_Lower',(30,18,1.32),(8,68,.24),'precast',2,.025,True)
box('Academic_Veranda_Upper',(30,18,5.24),(8,68,.22),'precast',2,.025,True)
box('Academic_Veranda_Roof',(30,18,9.09),(8.5,69,.26),'precast',2,.025)
box('Academic_LowerFoundation',(43,18,.6),(18,68,1.2),'brick',2,.015,True)
box('Academic_VerandaRetainingBase',(30,18,.6),(8,68,1.2),'precast',2,.018,True)
for bay in range(11):
    y=-12+bay*6
    for floor,z in [('L1',1.44),('L2',5.36)]:
        box('Academic_%s_Bay%02d_BrickBase'%(floor,bay),(34.08,y,z+.46),(.26,5.7,.92),'brick',2,.015,True)
        box('Academic_%s_Bay%02d_Header'%(floor,bay),(34.08,y,z+3.33),(.26,5.7,.42),'brick',2,.015)
        box('Academic_%s_Bay%02d_Glass'%(floor,bay),(33.91,y,z+1.96),(.035,5.15,2.08),'glass',2,.003)
        for dy in [-2.65,-.9,.9,2.65]:
            box('Academic_%s_Bay%02d_Mullion%s'%(floor,bay,dy),(33.85,y+dy,z+1.94),(.08,.065,2.16),'dark',2,.004)
        for zz in [.94,2.53,3.04]:box('Academic_%s_Bay%02d_Transom%s'%(floor,bay,zz),(33.85,y,z+zz),(.08,5.35,.065),'dark',2,.004)
        # Recessed classroom door, solid lower panel, glazing and a handle.
        box('Academic_%s_Class%02d_Door'%(floor,bay),(33.77,y-2.02,z+1.05),(.07,.91,2.1),'enamel',2,.008,True)
        box('Academic_%s_Class%02d_DoorLite'%(floor,bay),(33.715,y-2.02,z+1.51),(.022,.61,.71),'glass',2,.004)
        tube('Academic_%s_Class%02d_Handle'%(floor,bay),[(33.69,y-1.67,z+.92),(33.69,y-1.67,z+1.09)],.011,'steel',2,12)
        text('Academic_%s_Class%02d_Label'%(floor,bay),'%s%02d'%('1' if floor=='L1' else '2',bay+1),(33.69,y-2.02,z+2.3),.12,2,'west')
    # Brick piers divide the bays; columns align with the terrace edges.
    box('Academic_Bay%02d_FacadePier'%bay,(34.03,y-2.92,5.23),(.48,.34,7.58),'brick',2,.02,True)
    box('Academic_Bay%02d_ColonnadePier'%bay,(26.35,y-2.92,5.22),(.38,.42,7.55),'precast',2,.023,True)
    for z in [4.98,8.9]:
        box('Academic_Bay%02d_FrontFascia_%s'%(bay,z),(26.05,y,z),(.3,6,.32),'enamel',2,.012)
    # Slender shade fins cast a believable rhythm on the circulation deck.
    for yy in [y-1.8,y,y+1.8]:box('Academic_ShadeFin_%s'%str((bay,yy)),(33.4,yy,8.2),(1.3,.07,.055),'cream',2,.004)
    for z in [3.61,7.53]:
        box('Academic_EastWindow_%s_%s'%(bay,z),(52.015,y,z),(.045,4.65,1.75),'glass',2,.003)
        box('Academic_EastSill_%s_%s'%(bay,z),(52.1,y,z-.93),(.4,4.95,.11),'precast',2,.012)
        for dy in [-2.39,0,2.39]:box('Academic_EastMullion_%s_%s_%s'%(bay,z,dy),(52.07,y+dy,z),(.075,.065,1.86),'cream',2,.003)
        for zz in [-.9,.9]:box('Academic_EastHeader_%s_%s_%s'%(bay,z,zz),(52.06,y,z+zz),(.07,4.85,.055),'cream',2,.003)
for y in range(-15,52,6):
    rail('Academic_UpperBalustrade_%s'%y,(26.05,y,6.41),(26.05,min(y+5.8,52),6.41),2,radius=.027,supports=3,base_z=5.36)
    box('Academic_UpperKickrail_%s'%y,(26.05,min(y+2.9,49.2),5.54),(.08,5.8,.08),'dark',2,.006)
    for k in range(15):
        yy=y+k*.39
        if yy<52:tube('Academic_Baluster_%s_%s'%(y,k),[(26.05,yy,5.57),(26.05,yy,6.4)],.009,'dark',2,8)
for y in [-14,50]:tube('Academic_Downpipe_%s'%y,[(25.87,y,9),(25.87,y,1.5)],.043,'steel',2,16)
for y in [-13,20,49]:
    box('Academic_AC_%s'%y,(47,y,9.55),(2,1.4,.75),'precast',2,.05)
    for k in range(8):box('Academic_AC_Louvre_%s_%s'%(y,k),(47,y-.71,9.28+k*.085),(1.8,.025,.034),'dark',2,.003)
stairs('Academic_EightStair',5,21.2,7,8,zone=2,axis='x',handrails=True)
# Flight actually ascends west-to-east from x21.2 to24.08; landing joins x26.
box('Academic_EntranceLanding',(25.05,5,1.31),(1.94,7,.26),'precast',2,.015,True)
bank('Academic_AccessBank',(17,-9,0),(26,-9,1.44),6,2)
bank('Academic_NorthAccessBank',(17,42,0),(26,42,1.44),7,2)
for y in [18,32]:ledge('Academic_LowSeat_%s'%y,(23.1,y,.27),(1.15,7,.54),2)
# A visible, sensible route to the upper circulation deck.
stairs('Academic_UpperStairs',29.5,-15,3.8,22,rise=.17818,tread=.31,z0=1.44,zone=2,axis='y',direction=1)
box('Academic_UpperStairLanding',(29.5,-7.13,5.26),(3.8,2,.2),'precast',2,.015,True)
text('Academic_FacadeSign','EASTBANK  /  LEARNING WING',(25.88,17,8.45),.42,2,'west')

# LIBRARY: lower masonry volume, high clerestory sawtooth roof and raised entry.
box('Library_Floor',(5,40,2.03),(30,16,.26),'precast',3,.025,True)
box('Library_NorthWall',(5,47.85,4.5),(30,.32,4.68),'brick',3,.02,True)
for x in [-9.85,19.85]:box('Library_SideWall_%s'%x,(x,40,4.5),(.32,16,4.68),'brick',3,.02,True)
for x in [-8,-2,4,10,16]:
    box('Library_FrontPier_%s'%x,(x,32.09,4.46),(.48,.5,4.6),'brick',3,.022,True)
    box('Library_FrontGlazing_%s'%x,(x+2.65,32.02,4.48),(5.2,.04,3.9),'glass',3,.004)
    for xx in [x+.14,x+2.65,x+5.25]:box('Library_FrontMullion_%s'%str(xx),(xx,31.94,4.45),(.07,.08,4),'dark',3,.004)
box('Library_EntranceDoor',(5,31.88,3.38),(2,.08,2.44),'enamel',3,.01,True)
for x in [4.52,5.48]:box('Library_DoorGlass_%s'%x,(x,31.81,3.76),(.76,.025,1.22),'glass',3,.003)
for bay in range(3):
    y0=32+bay*5.33
    verts=[(-10,y0,6.85),(20,y0,6.85),(20,y0+4.85,8.35),(-10,y0+4.85,8.35)]
    mesh_obj('Library_SawtoothRoof_%s'%bay,verts,[(0,1,2,3)],'dark',3)
    box('Library_Clerestory_%s'%bay,(5,y0+4.87,7.53),(30,.035,1.47),'glass',3,.003)
    for x in range(-10,21,2):tube('Library_RoofRib_%s_%s'%(bay,x),[(x,y0,6.87),(x,y0+4.85,8.37)],.016,'steel',3,8)
box('Library_EntryCanopy',(5,30.85,5.6),(31,2.65,.23),'precast',3,.028)
box('Library_Terrace',(5.5,28.9,2.04),(31,6.2,.24),'precast',3,.023,True)
box('Library_Foundation',(5,40,.96),(30,16,1.92),'brick',3,.015,True)
box('Library_TerraceRetainingBase',(5.5,28.9,.96),(31,6.2,1.92),'precast',3,.016,True)
stairs('Library_TwelveStair',4.5,21.48,7,12,zone=3,tread=.36)
box('Library_StairLanding',(4.5,26.6,2.04),(7,1.62,.24),'precast',3,.014,True)
bank('Library_WestAccessBank',(-22,27,0),(-10,27,2.16),5,3)
bank('Library_EastAccessBank',(24,14,0),(24,27,2.16),5,3)
box('Library_EastRampLanding',(22.75,28.7,2.04),(5.5,3.4,.24),'precast',3,.018,True)
ledge('Library_TerraceLedge_W',(-4,26.35,2.47),(7,1,.62),3)
ledge('Library_TerraceLedge_E',(14,26.35,2.47),(7,1,.62),3)
text('Library_MainSign','LIBRARY  /  MEDIA LAB',(5,31.64,5.87),.53,3)
text('Library_SecondarySign','EASTBANK TECHNICAL COLLEGE',(5,31.66,6.48),.24,3)
joint_grid('Library_TerraceJoint',-10,21,25.8,32,2.163,3,3)

# CLOCK TOWER: original campus landmark with real hands and inset hour marks.
box('ClockTower_BrickCore',(-13,35,4.5),(2.5,2.5,9),'brick',3,.035,True)
box('ClockTower_Crown',(-13,35,9.14),(3,3,.28),'precast',3,.035)
box('ClockTower_Face',(-13,33.71,7.62),(1.95,.05,1.95),'cream',3,.02)
for i in range(12):
    a=i*PI/6;p=(-13+math.sin(a)*.78,33.663,7.62+math.cos(a)*.78)
    tube('ClockTower_HourMark_%02d'%i,[p,(p[0]-math.sin(a)*.13,p[1],p[2]-math.cos(a)*.13)],.015,'dark',3,8)
tube('ClockTower_MinuteHand',[(-13,33.64,7.62),(-12.47,33.64,7.95)],.024,'dark',3,12)
tube('ClockTower_HourHand',[(-13,33.63,7.62),(-13.18,33.63,8.05)],.03,'dark',3,12)
text('ClockTower_Date','EST. 1968',(-13,33.69,6.3),.19,3)

# SUNKEN ASSEMBLY FORUM. Every step/ledge is independently editable.
box('Assembly_LowerPlaza',(-9,8,-1.01),(20,10,.22),'concrete',4,.018,True)
for i in range(3):
    z=-.9+(i+1)*.3
    outerx=20+(i+1)*2.666;outery=10+(i+1)*2.666
    innerx=outerx-2.666;innery=outery-2.666
    # Four broad seats, west/east ends split to leave the banked exits unobstructed.
    for side in [-1,1]:
        box('Assembly_Terrace_%s_NorthSouth_%s'%(i,side),(-9,8+side*(innery/2+.666),z-.175),(outerx,1.333,.35),'precast',4,.025,True)
        for sy in [-1,1]:
            box('Assembly_Terrace_%s_End_%s_%s'%(i,side,sy),(-9+side*(innerx/2+.666),8+sy*(innery/4+1.5),z-.175),(1.333,innery/2-3,.35),'precast',4,.025,True)
        for yy in [8+side*(innery/2+.63)]:grind('Assembly_Seat_%s_%s'%(i,side),[(-9-outerx/2+.06,yy,z+.012),(-9+outerx/2-.06,yy,z+.012)],'ledge',.016,feature='Assembly_Terrace_%s'%i)
bank('Assembly_WestExit',(-19,8,-.9),(-23,8,0),6,4)
bank('Assembly_EastExit',(1,8,-.9),(5,8,0),6,4)
box('Assembly_Stage',(-9,13.7,-.19),(8,2.2,.42),'precast',4,.022,True)
for x in [-12.8,-5.2]:box('Assembly_CanopyColumn_%s'%x,(x,14.2,1.7),(.18,.18,4.1),'dark',4,.012,True)
for x in range(-13,-4):box('Assembly_ShadeSlat_%s'%x,(x,14.2,3.81),(.09,3.2,.15),'wood',4,.008)
for y in [13,15.4]:box('Assembly_ShadeBearer_%s'%y,(-9,y,3.71),(8.4,.13,.18),'dark',4,.008)
text('Assembly_StageInscription','MAKE  /  LEARN  /  MOVE',(-9,12.575,-.22),.16,4)
joint_grid('Assembly_FloorJoint',-19,1,3,13,-.896,4,2.5)

# SPORTS COURT: full dimensions, crisp original line geometry, detailed equipment.
box('Sports_Court',(-40,-10,.035),(28,32,.07),'court',5,.012,True,color=(.23,.49,.47,1))
def line(name,pts,width=.045,key='paint',zone=5):
    for k,(a,b) in enumerate(zip(pts,pts[1:])):
        a,b=Vector(a),Vector(b);v=(b-a).normalized();w=Vector((-v.y,v.x,0))*width/2
        mesh_obj(name+'_%03d'%k,[tuple(a-w),tuple(b-w),tuple(b+w),tuple(a+w)],[(0,1,2,3)],key,zone)
z=.074
line('Court_OuterLine',[(-53,-24,z),(-27,-24,z),(-27,4,z),(-53,4,z),(-53,-24,z)],.07)
line('Court_CentreLine',[(-53,-10,z),(-27,-10,z)],.065)
line('Court_CentreCircle',[(-40+1.8*math.cos(t*PI/64),-10+1.8*math.sin(t*PI/64),z) for t in range(129)],.055)
for end,y,sgn in [('North',4,-1),('South',-24,1)]:
    line('Court_'+end+'_Key',[(-42.45,y,z),(-42.45,y+sgn*5.8,z),(-37.55,y+sgn*5.8,z),(-37.55,y,z)],.055)
    line('Court_'+end+'_Arc',[(-40+6.5*math.cos(t*PI/96),y+sgn*(1.4+6.5*math.sin(t*PI/96)),z) for t in range(97)],.055)
    line('Court_'+end+'_FreeThrowCircle',[(-40+1.8*math.cos(t*2*PI/96),y+sgn*5.8+1.8*math.sin(t*2*PI/96),z) for t in range(97)],.04)
    # Proper pole, cantilever, bolted backboard, orange hoop and opaque cord net.
    py=y-sgn*1.2
    box('Hoop_'+end+'_Foot',(-40,py,.15),(.7,.7,.3),'precast',5,.03,True)
    tube('Hoop_'+end+'_Post',[(-40,py,.3),(-40,py,3.65),(-40,y+sgn*1.2,3.65)],.085,'dark',5,20,collision=True)
    box('Hoop_'+end+'_Backboard',(-40,y+sgn*1.15,3.62),(1.8,.06,1.08),'cream',5,.014)
    for x in [-40.32,-39.68]:box('Hoop_'+end+'_TargetEdge_'+str(x),(x,y+sgn*1.19,3.43),(.032,.005,.48),'terra',5,0)
    for h in [3.2,3.67]:box('Hoop_'+end+'_TargetHorizontal_'+str(h),(-40,y+sgn*1.19,h),(.65,.005,.032),'terra',5,0)
    ring=[(-40+.225*math.cos(i*2*PI/64),y+sgn*1.48+.225*math.sin(i*2*PI/64),3.05) for i in range(64)]
    tube('Hoop_'+end+'_Rim',ring,.012,'terra',5,12,closed=True)
    for i in range(12):
        a=i*2*PI/12;b=a+PI/12
        tube('Hoop_'+end+'_Net_%02d'%i,[(-40+.225*math.cos(a),y+sgn*1.48+.225*math.sin(a),3.05),(-40+.14*math.cos(b),y+sgn*1.48+.14*math.sin(b),2.62),(-40+.14*math.cos(b+PI/6),y+sgn*1.48+.14*math.sin(b+PI/6),2.62)],.0035,'cream',5,6)
ledge('Sports_EastSeat',(-24.4,-13,.29),(1.4,17,.58),5)
bank('Sports_NorthLowBank',(-39,7,0),(-39,5,.4),18,5)
box('Sports_NorthBankDeck',(-39,4.65,.3),(18,.7,.2),'precast',5,.013,True)
rail('Sports_FlatPracticeRail',(-22.5,-20,.46),(-22.5,-12,.46),5,supports=4)

# GYMNASIUM: an actual arched metal roof with continuous ribs and clerestories.
box('Gym_Floor',(-40,-38,.03),(30,14,.2),'precast',5,.023,True)
for y in [-44.9,-31.1]:box('Gym_LongWall_%s'%y,(-40,y,2.92),(30,.34,5.84),'brick',5,.02,True)
for x in [-54.9,-25.1]:box('Gym_EndWall_%s'%x,(x,-38,2.92),(.34,14,5.84),'brick',5,.02,True)
verts=[];faces=[]
for x in [-55.6,-24.4]:
    for i in range(97):
        t=i*PI/96;verts.append((x,-38+7.6*math.cos(t),5.9+2.55*math.sin(t)))
for i in range(96):faces.append((i,i+1,98+i,97+i))
mesh_obj('Gym_ContinuousBarrelRoof',verts,faces,'enamel',5,True)
for k in range(32):
    x=-55.4+k
    tube('Gym_RoofRib_%02d'%k,[(x,-38+7.6*math.cos(i*PI/64),5.91+2.55*math.sin(i*PI/64)) for i in range(65)],.023,'steel',5,8)
for x in range(-52,-25,4):
    box('Gym_Clerestory_%s'%x,(x,-30.87,5.13),(3.2,.04,1.06),'glass',5,.004)
    for dx in [-1.62,0,1.62]:box('Gym_WindowMullion_%s_%s'%(x,dx),(x+dx,-30.81,5.13),(.055,.075,1.15),'cream',5,.004)
for x in [-44,-40,-36]:box('Gym_EntryDoor_%s'%x,(x,-30.9,1.16),(1.6,.1,2.3),'enamel',5,.008,True)
box('Gym_DoorCanopy',(-40,-29.8,2.62),(12,2.7,.18),'precast',5,.023)
for x in [-55.55,-24.45]:tube('Gym_Gutter_%s'%x,[(x,-45.6,5.88),(x,-30.4,5.88)],.07,'steel',5,16)
text('Gym_FrontSign','SPORTS HALL',(-40,-30.68,3.82),.58,5)

# CANTEEN TERRACE: connected three-step / bank entrances, realistic picnic tables.
box('Canteen_Floor',(7,-43,.07),(28,12,.22),'precast',6,.02,True)
box('Canteen_BackWall',(7,-48.85,2.12),(28,.32,4.24),'brick',6,.022,True)
for x in [-6.85,20.85]:box('Canteen_EndWall_%s'%x,(x,-43,2.12),(.32,12,4.24),'brick',6,.022,True)
box('Canteen_Roof',(7,-43,4.38),(29,13,.25),'precast',6,.025)
for x in [-3,2,7,12,17]:
    box('Canteen_ServiceWindow_%s'%x,(x,-37.02,2.26),(4.6,.045,2.42),'glass',6,.005)
    box('Canteen_WindowSill_%s'%x,(x,-36.81,1.03),(4.85,.5,.12),'precast',6,.015)
    for dx in [-2.35,0,2.35]:box('Canteen_WindowFrame_%s_%s'%(x,dx),(x+dx,-36.95,2.22),(.065,.09,2.5),'dark',6,.004)
box('Canteen_ServiceCounter',(7,-36.52,1.17),(10,.7,.18),'wood',6,.018,True)
box('Canteen_EntranceDoor',(-4.6,-36.85,1.15),(1.25,.12,2.3),'enamel',6,.01,True)
text('Canteen_Sign','CANTEEN  /  SOCIAL CLUB',(7,-36.83,3.65),.47,6)
box('Canteen_Terrace',(5,-29,.43),(32,15,.22),'precast',6,.02,True)
box('Canteen_TerraceRetainingBase',(5,-29,.16),(32,15,.32),'precast',6,.018,True)
stairs('Canteen_ThreeStair',3,-20.42,9,3,zone=6,direction=-1)
bank('Canteen_WestBank',(-17,-27,0),(-11,-27,.54),6,6)
bank('Canteen_EastBank',(27,-27,0),(21,-27,.54),6,6)
joint_grid('Canteen_ExpansionJoint',-11,21,-36.5,-21.5,.543,6,3)
for x,y in [(-5,-28),(3,-30),(12,-29),(17,-33)]:
    base='Picnic_%s_%s'%(x,y)
    for k in range(7):box(base+'_TopSlat_%02d'%k,(x,y+(k-3)*.105,1.29),(2.9,.095,.055),'wood',6,.007,True)
    for sy in [-1,1]:
        for k in range(3):box(base+'_Seat_%s_%s'%(sy,k),(x,y+sy*.79+(k-1)*.08,1.01),(2.9,.07,.05),'wood',6,.006,True)
    for sx in [-1,1]:
        for sy in [-1,1]:tube(base+'_Leg_%s_%s'%(sx,sy),[(x+sx*1.02,y+sy*.62,.54),(x+sx*1.02,y+sy*.25,1.28)],.026,'dark',6,12)
        tube(base+'_SeatFrame_%s'%sx,[(x+sx*1.02,y-.91,.98),(x+sx*1.02,y+.91,.98)],.026,'dark',6,12)
    grind(base,[(x-1.4,y-.35,1.32),(x+1.4,y-.35,1.32)],'ledge',.02,feature=base)
for x in [-9,19]:
    for y in [-34,-23]:box('Canteen_PergolaPost_%s_%s'%(x,y),(x,y,2.5),(.16,.16,3.92),'dark',6,.013,True)
for y in [-34,-23]:box('Canteen_PergolaBeam_%s'%y,(5,y,4.46),(28.5,.18,.23),'dark',6,.014)
for x in range(-9,20):box('Canteen_ShadeSlat_%s'%x,(x,-28.5,4.59),(.13,11.8,.11),'wood',6,.01)
ledge('Canteen_LongTerraceEdge',(5,-21.75,.78),(7,.5,.48),6)

# WORKSHOP AND SERVICE COURT: roller doors, loading dock, gutters and equipment.
box('Workshop_Floor',(-44,42,.05),(32,12,.2),'precast',7,.024,True)
box('Workshop_BackWall',(-44,47.85,2.68),(32,.32,5.36),'brick',7,.022,True)
for x in [-59.85,-28.15]:box('Workshop_EndWall_%s'%x,(x,42,2.68),(.32,12,5.36),'brick',7,.022,True)
box('Workshop_Roof',(-44,42,5.62),(33.4,13.3,.22),'dark',7,.035)
for x in [-53,-44,-35]:
    box('Workshop_RollerDoor_%s'%x,(x,36.04,2.12),(6.5,.07,4.15),'enamel',7,.008,True)
    for k in range(31):box('Workshop_RollerDoorSlat_%s_%s'%(x,k),(x,35.975,.14+k*.132),(6.35,.024,.032),'steel',7,.003)
    box('Workshop_RollerDoorHeader_%s'%x,(x,35.84,4.37),(6.8,.34,.26),'dark',7,.015)
    for dx in [-3.4,3.4]:box('Workshop_RollerDoorGuide_%s_%s'%(x,dx),(x+dx,35.94,2.16),(.09,.15,4.32),'dark',7,.008)
box('Workshop_LoadingDock',(-43,33.8,.48),(25,4.3,.96),'precast',7,.022,True)
stairs('Workshop_SixStair',-55,29.5,3.2,6,rise=.16,tread=.36,zone=7)
bank('Workshop_DockBank',(-23,33,0),(-30.5,33,.96),5,7)
ledge('Workshop_DockEdge',(-43,31.78,1.05),(18,.46,.18),7)
box('Workshop_Canopy',(-44,34.95,4.95),(32.6,3,.18),'precast',7,.025)
for x in [-59,-29]:tube('Workshop_CanopyTie_%s'%x,[(x,33.5,4.93),(x,36,5.34)],.023,'steel',7,12)
text('Workshop_MainSign','DESIGN  /  FABRICATION',(-44,35.78,5.18),.5,7)
for x in [-57,-31]:tube('Workshop_Downpipe_%s'%x,[(x,35.77,5.48),(x,35.77,.22)],.045,'steel',7,16)
for x in [-50,-39]:
    box('Workshop_RoofVent_%s'%x,(x,43,6.05),(1.6,1.6,.75),'precast',7,.04)
    tube('Workshop_Exhaust_%s'%x,[(x,43,6.4),(x,43,7.05)],.28,'steel',7,24)
    box('Workshop_VentCap_%s'%x,(x,43,7.1),(.9,.9,.12),'steel',7,.015)

# DRY RETENTION BASIN: a 32 x 16 m continuous compound transition. The smooth
# analytic profile has horizontal tangency at the floor, 60-degree rim slopes.
cx,cy=-43,22;depth=1.8;rx,ry=16,8
N=256;RINGS=72;verts=[(cx,cy,-depth)];faces=[]
def super_outline(a,scale):
    co,si=math.cos(a),math.sin(a)
    return cx+rx*math.copysign(abs(co)**.5,co)*scale,cy+ry*math.copysign(abs(si)**.5,si)*scale
for j in range(1,RINGS+1):
    t=(j-1)/(RINGS-1)
    # Quarter-ellipse transitions with an actual vertical lip and a horizontal
    # floor tangent. Constant 2.6 m transition width preserves all four walls.
    offset=2.6*(1-math.sin(t*PI/2));z=-depth+depth*(1-math.cos(t*PI/2))
    for i in range(N):
        a=i*2*PI/N;co,si=math.cos(a),math.sin(a)
        x=cx+(rx-offset)*math.copysign(abs(co)**.5,co)
        y=cy+(ry-offset)*math.copysign(abs(si)**.5,si)
        verts.append((x,y,z))
for i in range(N):faces.append((0,1+i,1+(i+1)%N))
for j in range(RINGS-1):
    for i in range(N):
        a=1+j*N+i;b=1+j*N+(i+1)%N;c=1+(j+1)*N+(i+1)%N;d=1+(j+1)*N+i
        faces.append((a,d,c,b))
basin=mesh_obj('RetentionBasin_ContinuousTransition',verts,faces,'concrete',7,True,collision=True)
rim=[(*super_outline(i*2*PI/N,1),.035) for i in range(N)]
tube('RetentionBasin_RimSteel',rim,.035,'steel',7,20,True)
grind('RetentionBasin_Rim',rim,'coping',.035,True,feature=basin.name)
# Connect the squircle lip to the rectangular cutout, leaving no earth slit.
v=[];f=[]
for i in range(N):
    a=i*2*PI/N;x,y=super_outline(a,1);co,si=math.cos(a),math.sin(a)
    scale=min(rx/abs(co) if abs(co)>1e-8 else 1e8,ry/abs(si) if abs(si)>1e-8 else 1e8)
    v += [(x,y,0),(cx+scale*co,cy+scale*si,0)]
for i in range(N):k=(i+1)%N;f.append((i*2,i*2+1,k*2+1,k*2))
mesh_obj('RetentionBasin_DeckApron',v,f,'precast',7,collision=True)
box('RetentionBasin_Sump',(-43,22,-1.792),(1.2,.7,.015),'dark',7,0)
for i in range(16):box('RetentionBasin_DrainSlot_%02d'%i,(-43-.56+i*.075,22,-1.78),(.027,.61,.01),'steel',7,0)
bank('RetentionBasin_AccessSlope',(-43,18.6,-1.8),(-43,14,0),5,7)
text('RetentionBasin_Warning','DRY WEATHER COURT  /  KEEP DRAINS CLEAR',(-43,12.7,.012),.19,7,normal='up',key='dark',extrude=0)

# ENTRY, ADMIN AND STREET DETAILS. Believable hardware and honest dimensions.
box('Admin_Floor',(41,-39,.04),(18,14,.16),'precast',8,.02,True)
for x in [32.15,49.85]:box('Admin_EndWall_%s'%x,(x,-39,2.2),(.32,14,4.4),'brick',8,.02,True)
box('Admin_BackWall',(41,-45.8,2.2),(18,.32,4.4),'brick',8,.02,True)
box('Admin_Roof',(41,-39,4.58),(19,15,.24),'precast',8,.025)
for x in [35,40,45]:
    box('Admin_Glazing_%s'%x,(x,-32.08,2.1),(4.7,.04,3.8),'glass',8,.004)
    for dx in [-2.38,0,2.38]:box('Admin_Mullion_%s_%s'%(x,dx),(x+dx,-32.02,2.1),(.075,.08,3.85),'dark',8,.004)
for x in [35,40,45]:
    box('Admin_SouthWindow_%s'%x,(x,-45.985,2.26),(3.6,.035,1.65),'glass',8,.004)
    for dx in [-1.85,0,1.85]:box('Admin_SouthFrame_%s_%s'%(x,dx),(x+dx,-46.03,2.26),(.055,.08,1.75),'cream',8,.003)
    box('Admin_SouthSill_%s'%x,(x,-46.08,1.35),(3.9,.35,.11),'precast',8,.012)
box('Admin_Door',(48,-32,1.15),(1.1,.1,2.3),'enamel',8,.008,True)
text('Admin_Sign','ADMINISTRATION',(41,-31.91,4.07),.41,8)
for x in [-5,24]:
    box('Entry_GatePier_%s'%x,(x,-52.8,1.25),(.9,.9,2.5),'brick',8,.026,True)
    box('Entry_GateCap_%s'%x,(x,-52.8,2.55),(1.06,1.06,.15),'precast',8,.022)
box('Entry_IdentityWall',(34,-52.8,.8),(18,.5,1.6),'brick',8,.024,True)
box('Entry_IdentityPlaque',(34,-53.08,1.04),(15,.05,.85),'enamel',8,.02)
text('Entry_CollegeName','EASTBANK TECHNICAL COLLEGE',(34,-53.116,1.06),.44,8)
text('Entry_Address','58 RIVER ROAD  /  VISITORS VIA ADMINISTRATION',(34,-53.118,.84),.13,8)
for x,y in [(30,-24),(15,-10),(-15,-15),(-60,3),(28,50)]:bench('Campus_Bench_%s_%s'%(x,y),x,y,0,8,length=3.2)
for i in range(8):
    x=31+i*.8;y=-47.6
    pts=[(x,y-.38,.06),(x,y-.38,.7)]
    pts += [(x,y-.38+.38*(1-math.cos(k*PI/20)),.7+.38*math.sin(k*PI/20)) for k in range(1,21)]
    pts += [(x,y+.38,.06)]
    tube('Entry_BikeRack_%02d'%i,pts,.022,'steel',8,16,collision=True)
for x,y in [(-18,-38),(23,-18),(-20,24)]:
    box('Noticeboard_Frame_%s_%s'%(x,y),(x,y,1.72),(2.4,.13,1.5),'enamel',8,.016)
    box('Noticeboard_Face_%s_%s'%(x,y),(x,y-.079,1.72),(2.2,.015,1.3),'cream',8,.005)
    for dx in [-.95,.95]:box('Noticeboard_Post_%s_%s_%s'%(x,y,dx),(x+dx,y,.73),(.085,.085,1.46),'dark',8,.006,True)
    text('Noticeboard_Title_%s_%s'%(x,y),'CAMPUS NOTES',(x,y-.092,2.18),.17,8,key='dark')
    for i in range(4):
        box('Noticeboard_Poster_%s_%s_%s'%(x,y,i),(x-.75+i*.5,y-.095,1.68),(.38,.008,.57),'terra' if i%2 else 'yellow',8,.001)
        for j in range(4):box('Noticeboard_PosterLine_%s_%s_%s_%s'%(x,y,i,j),(x-.75+i*.5,y-.101,1.83-j*.08),(.23,.002,.012),'cream',8,0)
for x,y in [(-24,-34),(22,-38),(-18,39)]:
    box('WasteBin_%s_%s'%(x,y),(x,y,.52),(.63,.63,1.04),'enamel',8,.055,True)
    box('WasteBin_Lid_%s_%s'%(x,y),(x,y,1.04),(.72,.72,.09),'dark',8,.035)
    box('WasteBin_Opening_%s_%s'%(x,y),(x,y-.321,.83),(.42,.013,.16),'dark',8,.012)

# FENCING: opaque geometry, service openings and distinct school site boundary.
def fence(name,a,b,height=2.3,zone=1,chain=False):
    a,b=Vector(a),Vector(b);length=(b-a).length;segments=max(1,round(length/2.6))
    for k in range(segments+1):
        p=a.lerp(b,k/segments);tube(name+'_Post_%02d'%k,[tuple(p),tuple(p+Vector((0,0,height)))],.035,'dark',zone,12)
    for z in [.15,height]:tube(name+'_Horizontal_%s'%z,[tuple(a+Vector((0,0,z))),tuple(b+Vector((0,0,z)))],.018,'dark',zone,12)
    # Welded steel mesh at 120 mm spacing, actual opaque rods (no alpha cost).
    steps=math.ceil(length/.12)
    for k in range(steps+1):
        p=a.lerp(b,k/steps);tube(name+'_WireV_%03d'%k,[tuple(p+Vector((0,0,.15))),tuple(p+Vector((0,0,height)))],.0028,'dark',zone,5)
    for k in range(1,round((height-.15)/.16)):
        zz=.15+k*.16;tube(name+'_WireH_%03d'%k,[tuple(a+Vector((0,0,zz))),tuple(b+Vector((0,0,zz)))],.0028,'dark',zone,5)
fence('Court_WestFence',(-54.5,-25,0),(-54.5,5,0),3.1,5)
fence('Court_SouthFence',(-54.5,-25,0),(-44,-25,0),3.1,5)
fence('Court_SouthFenceEast',(-36,-25,0),(-25.5,-25,0),3.1,5)
fence('Campus_WestFence',(-65,-50,0),(-65,52,0),2,1)
fence('Campus_NorthFence',(-65,53,0),(60,53,0),2,1)
fence('Campus_EastFence',(64,-51,0),(64,52,0),2,1)
fence('Entry_WestBoundary',(-65,-52.8,0),(-7,-52.8,0),1.8,1)
fence('Entry_EastBoundary',(44,-52.8,0),(64,-52.8,0),1.8,1)

# PLANTERS, ORIGINAL EUCALYPTUS TREES AND LOW SHRUBS: enough enclosure to make
# a location while keeping sightlines and approaches open.
tree_positions=[(-61,-43),(-61,-24),(-60,6),(-60,35),(-22,47),(24,46),(59,42),(59,22),(59,1),(58,-20),(55,-46),(-16,-43),(-18,-25),(17,13),(15,-9),(-23,19),(-10,52),(45,58),(-73,20),(74,-12)]
def tapered_branch(name,points,radii,sides=16):
    pts=[Vector(p) for p in points];v=[];f=[]
    for i,p in enumerate(pts):
        t=(pts[min(i+1,len(pts)-1)]-pts[max(0,i-1)]).normalized()
        ref=Vector((0,0,1)) if abs(t.z)<.92 else Vector((1,0,0))
        u=t.cross(ref).normalized();w=t.cross(u).normalized()
        for j in range(sides):
            a=j*2*PI/sides;r=radii[i]*(1+.055*math.sin(j*5+i*.35))
            v.append(tuple(p+r*(math.cos(a)*u+math.sin(a)*w)))
    for i in range(len(pts)-1):
        for j in range(sides):f.append((i*sides+j,i*sides+(j+1)%sides,(i+1)*sides+(j+1)%sides,(i+1)*sides+j))
    f += [tuple(range(sides-1,-1,-1)),tuple((len(pts)-1)*sides+j for j in range(sides))]
    return mesh_obj(name,v,f,'bark',9,True)

for ti,(x,y) in enumerate(tree_positions):
    rng=random.Random(1251+ti%4);scale=.83+.12*(ti%4);angle=ti*.73
    def tp(p):
        px,py,pz=p;return (x+scale*(px*math.cos(angle)-py*math.sin(angle)),y+scale*(px*math.sin(angle)+py*math.cos(angle)),.12+scale*pz)
    trunk_pts=[(.06*math.sin(i*.8),.1*math.sin(i*.55),i*.53) for i in range(16)]
    tapered_branch('Eastbank_Eucalyptus_%02d_Trunk'%(ti+1),[tp(p) for p in trunk_pts],[scale*(.24*(1-i/19)+.025) for i in range(16)],20)
    leafv=[];leaff=[]
    for crown in range(9):
        a=crown*2.399;r=1.3+(.42*(crown%5));cz=6.2+(.6*(crown%4))
        target=Vector((math.cos(a)*r,math.sin(a)*r,cz));anchor=Vector((0,0,2.9+.27*crown))
        branch=[]
        for k in range(13):
            t=k/12;p=anchor.lerp(target,t);p.z+=.36*math.sin(t*PI);branch.append(tuple(p))
        tapered_branch('Eastbank_Eucalyptus_%02d_Branch_%02d'%(ti+1,crown),[tp(p) for p in branch],[scale*(.086*(1-k/13)+.011) for k in range(13)],12)
        for twig in range(12):
            az=twig*2.399+rng.random();rr=rng.uniform(.55,1.5)
            endpoint=target+Vector((math.cos(az)*rr,math.sin(az)*rr,rng.uniform(-.35,1.05)))
            stem=target*.65+anchor*.35
            points=[tuple(stem.lerp(endpoint,k/5)+Vector((0,0,.18*math.sin(k*PI/5)))) for k in range(6)]
            tapered_branch('Eastbank_Eucalyptus_%02d_Twig_%02d_%02d'%(ti+1,crown,twig),[tp(p) for p in points],[scale*(.023*(1-k/6)+.003) for k in range(6)],7)
        for li in range(540):
            az=rng.uniform(0,2*PI);u=rng.uniform(-1,1);rr=rng.random()**(1/3)
            c=target+Vector((math.cos(az)*math.sqrt(1-u*u)*rr*1.6,math.sin(az)*math.sqrt(1-u*u)*rr*1.6,u*rr*1.2))
            length=rng.uniform(.19,.34);wa=rng.uniform(.012,.025)
            direction=Vector((rng.uniform(-.7,.7),rng.uniform(-.7,.7),rng.uniform(-1,-.2))).normalized()
            side=direction.cross(Vector((0,0,1))).normalized()*wa
            mid=c+direction*length*.5+Vector((0,0,.02));tip=c+direction*length
            start=len(leafv);leafv += [tp(c),tp(mid-side),tp(mid+Vector((0,0,.009))),tp(mid+side),tp(tip)]
            leaff += [(start,start+1,start+2),(start,start+2,start+3),(start+1,start+4,start+2),(start+2,start+4,start+3)]
    mesh_obj('Eastbank_Eucalyptus_%02d_Canopy'%(ti+1),leafv,leaff,'leaf',9,True)
    # Trunk collision remains separately identifiable, not a whole canopy block.
    tube('Tree_%02d_TrunkCollisionGuide'%ti,[(x,y,.12),(x,y,2.6)],.22,'bark',9,12,collision=True)
    if -65<x<65 and -54<y<54:
        box('Planter_%02d_Soil'%ti,(x,y,.12),(3.9,3.9,.2),'soil',9,.02)
        for side in [-1,1]:
            ledge('Planter_%02d_CurbX_%s'%(ti,side),(x,y+side*2.03,.25),(4.35,.3,.5),9)
            ledge('Planter_%02d_CurbY_%s'%(ti,side),(x+side*2.03,y,.25),(.3,3.75,.5),9)
        for k in range(6):
            px=x+random.uniform(-1.6,1.6);py=y+random.uniform(-1.6,1.6)
            # Botanical rosettes: shaped opaque tapering blades, not sphere blobs.
            vv=[];ff=[]
            for blade in range(14):
                a=blade*2*PI/14+random.uniform(-.2,.2);r=random.uniform(.28,.55);h=random.uniform(.2,.45)
                start=len(vv);vv += [(px,py,.24),(px+math.cos(a)*r*.65-math.sin(a)*.018,py+math.sin(a)*r*.65+math.cos(a)*.018,.24+h),(px+math.cos(a)*r,py+math.sin(a)*r,.26),(px+math.cos(a)*r*.65+math.sin(a)*.018,py+math.sin(a)*r*.65-math.cos(a)*.018,.24+h)]
                ff += [(start,start+1,start+2),(start,start+2,start+3)]
            mesh_obj('Planter_%02d_Dianella_%02d'%(ti,k),vv,ff,'leaf',9,True)
for x,y in [(-19,-9),(22,20),(-24,-48),(55,34)]:
    tube('Campus_Lamp_%s_%s'%(x,y),[(x,y,0),(x,y,5.6)],.06,'dark',8,20,collision=True)
    box('Campus_LampHead_%s_%s'%(x,y),(x,y,5.66),(.8,.45,.12),'dark',8,.022)
    box('Campus_LampLens_%s_%s'%(x,y),(x,y,5.585),(.65,.33,.015),'cream',8,.005)

# Small campus-specific details give the terraces a purpose beyond skating.
for x,y,z,zone in [(26.7,17,1.44,2),(-7,30,2.16,3),(18,-35,.54,6)]:
    base='DrinkingFountain_%s_%s'%(x,y)
    box(base+'_Pedestal',(x,y,z+.4),(.32,.38,.8),'steel',zone,.035,True)
    box(base+'_Tray',(x,y,z+.84),(.55,.5,.065),'steel',zone,.05)
    tube(base+'_Tap',[(x+.13,y,z+.86),(x+.13,y,z+.97),(x+.02,y,z+.97)],.014,'steel',zone,12)
    tube(base+'_Drain',[(x-.1,y,z+.875),(x-.1,y,z+.88)],.027,'dark',zone,16)
for i in range(8):
    x=31.5;y=35+i*.56;z=1.44
    box('Academic_Locker_%02d'%i,(x,y,z+.92),(.54,.52,1.84),'enamel',2,.012,True)
    for zz in [.33,1.1,1.7]:
        for j in range(3):box('Academic_LockerVent_%02d_%s_%s'%(i,zz,j),(x-.279,y,z+zz+j*.032),(.008,.34,.01),'dark',2,.001)
    box('Academic_LockerLatch_%02d'%i,(x-.286,y+.17,z+.97),(.018,.047,.1),'steel',2,.005)
    text('Academic_LockerNumber_%02d'%i,str(81+i),(x-.291,y,z+1.55),.075,2,'west')
for i in range(3):
    x=-30+i*.45;y=45
    tube('Workshop_ServicePipe_%02d'%i,[(x,y,.1),(x,y,4.5),(x+1.2,y,4.5)],.045,'steel',7,16)
    for z in [1.1,3.5]:box('Workshop_PipeClamp_%s_%s'%(i,z),(x,y+.02,z),(.16,.08,.09),'dark',7,.008)
box('Workshop_ElectricalCabinet',(-28.01,40,1.12),(.15,1.5,1.7),'enamel',7,.015)
for j in range(7):box('Workshop_CabinetVent_%02d'%j,(-27.925,40,1.58+j*.04),(.01,1.13,.012),'dark',7,.001)


# Integration metadata uses the existing game's local Y-up grind-point format.
marker('Spawn_Entrance',(10,-47,0),{'role':'spawn','level':'eastbank-school','heading_radians':0})
marker('Spawn_Library',(4,28,2.16),{'role':'spawn','heading_radians':PI})
marker('Spawn_Workshop',(-40,33.5,.96),{'role':'spawn'})
for name,points in [
 ('Library_To_Assembly',[(5,29,2.16),(5,21,0),(-9,8,-.9),(-23,8,0),(-40,-10,.07)]),
 ('Canteen_To_Academic',[(3,-30,.54),(3,-18,0),(19,-9,0),(30,-9,1.44),(30,30,1.44)]),
 ('Service_To_Basin',[(-44,34,.96),(-44,30,0),(-43,22,-1.8),(-43,12,0),(-40,0,.07)])]:
    marker('ROUTE_'+name,props={'role':'route_hint','points':[v for x,y,z in points for v in (x,z,-y)],'coordinate_system':'local glTF Y-up metres'})
for name,pos in [('Library_Lip',(4.5,25.8,2.16)),('LoadingDock_Lip',(-43,31.65,.96)),('Basin_SouthLip',(-43,14,0))]:
    marker('TRANSFER_'+name,pos,{'role':'transfer_hint'})

# Give each authored mesh an intuitive independent origin while retaining baked
# real-metre UVs and exact world positions. Grind-path empties remain at identity.
for o in SOURCE_VISIBLE+COLLIDERS:
    if o.type!='MESH' or not o.data.vertices:continue
    coords=[v.co.copy() for v in o.data.vertices]
    center=Vector([(min(v[i] for v in coords)+max(v[i] for v in coords))/2 for i in range(3)])
    for v in o.data.vertices:v.co-=center
    o.location+=o.matrix_world.to_3x3()@center
    o['origin_policy']='Independent mesh bounds centre, world metres'

info={
 'name':'Eastbank Technical College','version':'1.0 visual campus','units':'metres',
 'authoring_axes':'Blender X east / Y north / Z up','runtime_axes':'glTF X east / Y up / Z south',
 'campus_extent_m':[132,108],
 'source':'source/levels/eastbank-school.blend','asset':'dist/assets/levels/eastbank-school.glb',
 'integration':'Separate visual asset. Existing application and Sonnet mechanics are untouched.',
 'grind_paths':'PATH_* empties at identity transform; flat points in local glTF Y-up metres; closed/radius/kind/source_feature extras.',
 'collision':'COL_* nodes, role=collision; hide in runtime; independently editable source objects.',
 'authoring':'Source objects keep names, materials, UVs and live edge bevels. Runtime copies batch by campus area and material without reducing geometry.',
 'areas':{v[3:]:v for v in ZONE_KEYS.values()},
 'routes':['Library twelve-stair -> sunken forum -> sports court','Canteen terrace -> academic bank -> colonnade','Workshop six-stair / dock -> dry basin -> court'],
 'next_session':'Inspect LEVEL_INFO.json and BUILD_EASTBANK.py Text datablocks. Edit an individual named source feature, then rebuild runtime from the source collections. No renderer changes or foveation belong in this asset.',
 'performance':'No Quest hardware profiling performed. No foveation, custom visibility, LOD switching or geometry decimation added.'
}
info['runtime_encoding']='Original 2048px JPEG PBR maps; lossless Meshopt buffer compression with full Float32 positions and normals. No quantisation or texture resizing.'
scene['level_name']=info['name'];scene['level_id']='eastbank-school';scene['level_metadata']=json.dumps(info)
t=bpy.data.texts.new('LEVEL_INFO.json');t.write(json.dumps(info,indent=2))
t=bpy.data.texts.new('BUILD_EASTBANK.py');t.write(Path(__file__).read_text())

# Natural light and documented inspection cameras, excluded from GLB export.
world=bpy.data.worlds.new('Eastbank clear late-afternoon sky');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.63,.74,.85,1)
world.node_tree.nodes['Background'].inputs[1].default_value=.45
sun_data=bpy.data.lights.new('Sun afternoon west','SUN');sun_data.energy=2.1;sun_data.angle=.085
sun=bpy.data.objects.new('Sun afternoon west',sun_data);COLS['13_Lighting'].objects.link(sun);sun.rotation_euler=(.43,-.55,-.6)
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True
scene.render.resolution_x=1600;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
try:scene.view_settings.look='AgX - Medium High Contrast'
except:pass
CAMERAS={
 '01_CampusOverview':((116,-134,96),(0,2,1),52),
 '02_LibraryAssembly':((-27,-8,10),(6,27,2.8),32),
 '03_AcademicColonnade':((21,-12,4.5),(31,21,4.1),32),
 '04_ServiceBasin':((-22,-2,10),(-45,28,1.5),35),
 '05_CanteenSports':((21,-9,7),(-11,-33,2.4),34),
 '07_BasinHumanScale':((-44,18,-.15),(-41,27,-.65),26),
 '06_HumanScaleEntry':((8,-59,1.7),(6,12,3.5),24),
}
for name,(pos,target,lens) in CAMERAS.items():
    data=bpy.data.cameras.new(name);data.lens=lens;data.clip_end=500
    o=bpy.data.objects.new(name,data);COLS['13_Lighting'].objects.link(o);o.location=pos;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
scene.camera=bpy.data.objects['01_CampusOverview']
print('Source objects',len(SOURCE_VISIBLE),'colliders',len(COLLIDERS),'grind paths',len(PATHS),flush=True)

# Build evaluated static batches for export, keeping every editable source object.
# This is purely an asset organisation step; no view-dependent rendering code.
bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get()
batches=defaultdict(list)
for o in SOURCE_VISIBLE:
    mat=o.data.materials[0] if o.data.materials else M['concrete']
    batches[(o.get('area','Site'),mat.name)].append(o)
runtime=[]
def combine(name,objects,visible=True):
    vv=[];ff=[];uvs=[];colors=[];smooth=[];normals=[];offset=0
    for o in objects:
        ev=o.evaluated_get(deps);me=ev.to_mesh(preserve_all_data_layers=True,depsgraph=deps)
        matrix=o.matrix_world
        normal_matrix=matrix.to_3x3().inverted().transposed()
        vv.extend(tuple(matrix@v.co) for v in me.vertices)
        uv=me.uv_layers.active;cc=me.color_attributes.active_color
        for p in me.polygons:
            ff.append(tuple(offset+i for i in p.vertices));smooth.append(p.use_smooth)
            for li in p.loop_indices:
                uvs.append(tuple(uv.data[li].uv) if uv else (0,0))
                colors.append(tuple(cc.data[li].color) if cc and cc.domain=='CORNER' else (1,1,1,1))
                normals.append(tuple((normal_matrix@me.corner_normals[li].vector).normalized()))
        offset+=len(me.vertices);ev.to_mesh_clear()
    me=bpy.data.meshes.new(name+'_Mesh');me.from_pydata(vv,[],ff);me.update();me.materials.append(objects[0].data.materials[0])
    uv=me.uv_layers.new(name='UVMap');uv.data.foreach_set('uv',[x for pair in uvs for x in pair])
    cc=me.color_attributes.new(name='Surface_Tint',type='FLOAT_COLOR',domain='CORNER');cc.data.foreach_set('color',[x for c in colors for x in c]);me.color_attributes.active_color=cc
    for p in me.polygons:p.use_smooth=True
    me.normals_split_custom_set(normals)
    o=bpy.data.objects.new(name,me);COLS['14_Runtime'].objects.link(o);o['role']='environment' if visible else 'collision'
    o['source_features']=json.dumps([x.name for x in objects]);o.hide_render=True;runtime.append(o);return o
groups={}
for (area,matname),objects in sorted(batches.items()):
    if area not in groups:
        g=bpy.data.objects.new('AREA_'+area,None);COLS['14_Runtime'].objects.link(g);g['role']='area';g['area']=area;groups[area]=g;runtime.append(g)
    o=combine('ENV_'+area+'_'+matname.split('|')[0].strip().replace(' ','_'),objects);o.parent=groups[area];o['area']=area
# One collision mesh per architectural area keeps the future loader's AABB candidate
# tests meaningful while the source's individual collider meshes remain editable.
coll_by_area=defaultdict(list)
for o in COLLIDERS:coll_by_area[o.get('area','Site')].append(o)
for area,objects in sorted(coll_by_area.items()):
    o=combine('COL_'+area,objects,False);o['area']=area
    o.parent=groups.get(area)

visible_tris=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in runtime if o.type=='MESH' and o.get('role')=='environment')
collision_tris=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in runtime if o.type=='MESH' and o.get('role')=='collision')
stats={'editable_visible_objects':len(SOURCE_VISIBLE),'editable_collision_objects':len(COLLIDERS),'visible_triangles':visible_tris,'collision_triangles':collision_tris,'visible_mesh_batches':sum(o.type=='MESH' and o.get('role')=='environment' for o in runtime),'grind_paths':len(PATHS),'markers':len(MARKERS),'materials':len({o.data.materials[0].name for o in runtime if o.type=='MESH' and o.get('role')=='environment'})}
info['measured_source_stats']=stats;bpy.data.texts['LEVEL_INFO.json'].clear();bpy.data.texts['LEVEL_INFO.json'].write(json.dumps(info,indent=2))
scene['level_metadata']=json.dumps(info);(OUT/'stats.json').write_text(json.dumps(stats,indent=2))
bpy.ops.file.pack_all()
SOURCE.parent.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=str(SOURCE),compress=True)
print('Saved editable master',SOURCE,stats,flush=True)

bpy.ops.object.select_all(action='DESELECT')
export_objects=runtime+PATHS+MARKERS
for o in export_objects:o.hide_set(False);o.hide_render=False;o.select_set(True)
scene['export_note']='Static runtime selection only. Edit source collections; runtime copies are generated.'
bpy.ops.export_scene.gltf(filepath=str(RAW_GLB),export_format='GLB',use_selection=True,export_extras=True,export_yup=True,export_apply=True,export_texcoords=True,export_normals=True,export_materials='EXPORT',export_image_format='AUTO',export_cameras=False,export_lights=False,export_animations=False)
for o in runtime:o.hide_render=True;o.select_set(False)
print('Exported GLB',RAW_GLB,RAW_GLB.stat().st_size,flush=True)
export_text=bpy.data.texts.new('EXPORT_CURRENT.py')
export_text.write((OUT/'export_current.py').read_text())
pack_text=bpy.data.texts.new('PACK_GLB.mjs');pack_text.write((OUT/'pack_glb.mjs').read_text())
# Keep the authoritative file lean: generated runtime geometry lives in the GLB.
# The embedded exporter regenerates batches from the currently edited objects.
for o in list(COLS['14_Runtime'].objects):
    data=o.data;bpy.data.objects.remove(o,do_unlink=True)
    if data and data.users==0:bpy.data.meshes.remove(data)
info['authoring']='Named source geometry is authoritative. EXPORT_CURRENT.py rebuilds GLB batches from the currently edited scene; BUILD_EASTBANK.py recreates the initial design.'
bpy.data.texts['LEVEL_INFO.json'].clear();bpy.data.texts['LEVEL_INFO.json'].write(json.dumps(info,indent=2));scene['level_metadata']=json.dumps(info)
bpy.ops.wm.save_as_mainfile(filepath=str(SOURCE),compress=True)
print('EASTBANK_BUILD_COMPLETE',flush=True)
