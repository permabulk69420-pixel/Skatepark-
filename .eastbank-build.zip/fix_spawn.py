import bpy, json, os, struct
from pathlib import Path
repo=Path(os.environ['EASTBANK_REPO'])
source=repo/'source/levels/eastbank-school.blend'
asset=repo/'dist/assets/levels/eastbank-school.glb'
bpy.ops.wm.open_mainfile(filepath=str(source))
spawn=bpy.data.objects['Spawn_Entrance']
spawn.location=(22,-48,0)
build=bpy.data.texts['BUILD_EASTBANK.py']
body=build.as_string().replace("marker('Spawn_Entrance',(10,-47,0)","marker('Spawn_Entrance',(22,-48,0)")
build.clear();build.write(body)
bpy.context.scene['entrance_spawn_blender_m']=[22,-48,0]
bpy.ops.wm.save_as_mainfile(filepath=str(source),compress=True)
raw=asset.read_bytes()
magic,version,old_total=struct.unpack_from('<4sII',raw)
assert magic==b'glTF' and version==2 and old_total==len(raw)
json_length,json_type=struct.unpack_from('<II',raw,12)
assert json_type==0x4e4f534a
data=json.loads(raw[20:20+json_length])
matches=[n for n in data['nodes'] if n.get('name')=='Spawn_Entrance']
assert len(matches)==1
matches[0]['translation']=[22,0,48]
encoded=json.dumps(data,separators=(',',':'),ensure_ascii=False).encode('utf8')
encoded+=b' '*((-len(encoded))%4)
binary=raw[20+json_length:]
out=struct.pack('<4sII',b'glTF',2,20+len(encoded)+len(binary))+struct.pack('<II',len(encoded),json_type)+encoded+binary
asset.write_bytes(out)
assert out[20+len(encoded):]==binary
print('Placed entrance spawn in the open walkway; retained every geometry and texture byte.')
