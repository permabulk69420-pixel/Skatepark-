import bpy, json, os, ast, math
from mathutils import Vector
from pathlib import Path
repo=Path(os.environ['EASTBANK_REPO'])
source=repo/'source/levels/eastbank-school.blend'
asset=repo/'dist/assets/levels/eastbank-school.glb'
bpy.ops.wm.open_mainfile(filepath=str(source))
spawn=bpy.data.objects['Spawn_Entrance']
spawn.location=(22,-48,0)
build=bpy.data.texts['BUILD_EASTBANK.py']
body=build.as_string().replace("marker('Spawn_Entrance',(10,-47,0)","marker('Spawn_Entrance',(22,-48,0)")
build.clear();build.write(body)
bpy.context.scene['entrance_spawn_blender_m']=[22,-48,0]
roof_code='''
_gym_roof=bpy.data.objects['Gym_ContinuousBarrelRoof']
_roof_sheet=_gym_roof.modifiers.new('Continuous folded metal roof sheet','SOLIDIFY')
_roof_sheet.thickness=.08;_roof_sheet.offset=-1
for _label,_x in [('West',-54.9),('East',-25.1)]:
    _outline=[(-45,5.82)]
    _outline += [(-45+14*_i/64,5.9+2.55*math.sqrt(1-((-7+14*_i/64)/7.6)**2)-.05) for _i in range(65)]
    _outline += [(-31,5.82)]
    _n=len(_outline)
    _verts=[(_xx,_yy,_zz) for _xx in [_x-.17,_x+.17] for _yy,_zz in _outline]
    _faces=[tuple(range(_n)),tuple(range(2*_n-1,_n-1,-1))]
    _faces += [(_i,_n+_i,_n+(_i+1)%_n,(_i+1)%_n) for _i in range(_n)]
    mesh_obj('Gym_ArchEndInfill_'+_label,_verts,_faces,'brick',5,collision=True)
for _label,_y in [('North',-31.1),('South',-44.9)]:
    _y0,_y1=_y-.17,_y+.17
    _z0=5.9+2.55*math.sqrt(1-((_y0+38)/7.6)**2)-.05
    _z1=5.9+2.55*math.sqrt(1-((_y1+38)/7.6)**2)-.05
    _v=[(-55,_y0,5.82),(-25,_y0,5.82),(-25,_y1,5.82),(-55,_y1,5.82),(-55,_y0,_z0),(-25,_y0,_z0),(-25,_y1,_z1),(-55,_y1,_z1)]
    _f=[(3,2,1,0),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)]
    mesh_obj('Gym_UpperWallFrieze_'+_label,_v,_f,'brick',5,collision=True)
'''
if 'Gym_ArchEndInfill_West' not in bpy.data.objects:
    COLS={c.name:c for c in bpy.context.scene.collection.children}
    ZONE_KEYS={5:'05_Sports'}
    M={'brick':bpy.data.materials['Brick | fired clay retaining walls / 1.6m'],'collision':bpy.data.materials['Collision | inspection only']}
    SOURCE_VISIBLE=[o for o in bpy.context.scene.objects if o.get('role')=='environment']
    COLLIDERS=list(COLS['10_Collision'].objects)
    ns,nc=len(SOURCE_VISIBLE),len(COLLIDERS)
    helpers=[n for n in ast.parse(build.as_string()).body if isinstance(n,ast.FunctionDef) and n.name in {'uv_color','mesh_obj','collider'}]
    exec(compile(ast.Module(body=helpers,type_ignores=[]),'campus_authoring_helpers','exec'))
    exec(roof_code)
    for o in SOURCE_VISIBLE[ns:]+COLLIDERS[nc:]:
        coords=[v.co.copy() for v in o.data.vertices]
        center=Vector([(min(v[i] for v in coords)+max(v[i] for v in coords))/2 for i in range(3)])
        for v in o.data.vertices:v.co-=center
        o.location+=center;o['origin_policy']='Independent mesh bounds centre, world metres'
    body=build.as_string().replace("mesh_obj('Gym_ContinuousBarrelRoof',verts,faces,'enamel',5,True)","mesh_obj('Gym_ContinuousBarrelRoof',verts,faces,'enamel',5,True)\n"+roof_code)
    build.clear();build.write(body)
info=json.loads(bpy.data.texts['LEVEL_INFO.json'].as_string())
stats=info['measured_source_stats']
visible=[o for o in bpy.context.scene.objects if o.get('role')=='environment']
colliders=list(bpy.data.collections['10_Collision'].objects)
bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get()
def tris(objects):
    total=0
    for o in objects:
        ev=o.evaluated_get(deps);me=ev.to_mesh();me.calc_loop_triangles();total+=len(me.loop_triangles);ev.to_mesh_clear()
    return total
stats.update(editable_visible_objects=len(visible),editable_collision_objects=len(colliders),visible_triangles=tris(visible),collision_triangles=tris(colliders))
info['version']='1.1 visual campus';info['roof_detail']='Sports hall has a continuous metal sheet, curved end infills and upper masonry closures.'
metadata=bpy.data.texts['LEVEL_INFO.json'];metadata.clear();metadata.write(json.dumps(info,indent=2))
bpy.context.scene['level_metadata']=json.dumps(info)
(Path(__file__).resolve().parent/'stats.json').write_text(json.dumps(stats,indent=2))
pack=bpy.data.texts['PACK_GLB.mjs'];pack.clear();pack.write((Path(__file__).resolve().parent/'pack_glb.mjs').read_text())
bpy.ops.wm.save_as_mainfile(filepath=str(source),compress=True)
exec(compile(bpy.data.texts['EXPORT_CURRENT.py'].as_string(),'EXPORT_CURRENT.py','exec'))
print('Re-exported the saved campus with the corrected entrance and original material colours.')
