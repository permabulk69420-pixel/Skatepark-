import bpy, json, os
from pathlib import Path
repo=Path(os.environ['EASTBANK_REPO'])
source=repo/'source/levels/eastbank-school.blend'
asset=repo/'dist/assets/levels/eastbank-school.glb'
bpy.ops.wm.open_mainfile(filepath=str(source))
spawn=bpy.data.objects['Spawn_Entrance']
spawn.location=(22,-48,0)
build=bpy.data.texts['BUILD_EASTBANK.py']
body=build.as_string().replace("marker('Spawn_Entrance',(10,-47,0)","marker('Spawn_Entrance',(22,-48,0)")
build.clear();build.write(body)
bpy.context.scene['entrance_spawn_blender_m']=[22,-48,0]
pack=bpy.data.texts['PACK_GLB.mjs'];pack.clear();pack.write((Path(__file__).resolve().parent/'pack_glb.mjs').read_text())
bpy.ops.wm.save_as_mainfile(filepath=str(source),compress=True)
exec(compile(bpy.data.texts['EXPORT_CURRENT.py'].as_string(),'EXPORT_CURRENT.py','exec'))
print('Re-exported the saved campus with the corrected entrance and original material colours.')
