# Run this packed Text in Blender after editing source objects.
# Produces an uncompressed GLB for the existing Three.js loader.
# No scene recreation, renderer settings or gameplay code are involved.
import bpy,json
from pathlib import Path
from collections import defaultdict
scene=bpy.context.scene
repo=Path(bpy.path.abspath('//')).resolve().parent.parent
COLS={c.name:c for c in scene.collection.children}
for o in list(COLS['14_Runtime'].objects):
    data=o.data;bpy.data.objects.remove(o,do_unlink=True)
    if data and data.users==0:bpy.data.meshes.remove(data)
SOURCE_VISIBLE=[o for o in scene.objects if o.type in {'MESH','FONT'} and o.get('role')=='environment']
COLLIDERS=list(COLS['10_Collision'].objects)
PATHS=list(COLS['11_GrindPaths'].objects)
MARKERS=list(COLS['12_Markers'].objects)
M={'concrete':bpy.data.materials['Concrete | trowelled aggregate / 4m repeat']}
bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get()
batches=defaultdict(list)
for o in SOURCE_VISIBLE:
    mat=o.data.materials[0] if o.data.materials else M['concrete']
    batches[(o.get('area','Site'),mat.name)].append(o)
runtime=[]
def combine(name,objects,visible=True):
    vv=[];ff=[];uvs=[];colors=[];smooth=[];normals=[];offset=0
    for o in objects:
        ev=o.evaluated_get(deps);me=ev.to_mesh(preserve_all_data_layers=True,depsgraph=deps)
        matrix=o.matrix_world
        normal_matrix=matrix.to_3x3().inverted().transposed()
        vv.extend(tuple(matrix@v.co) for v in me.vertices)
        uv=me.uv_layers.active;cc=me.color_attributes.active_color
        for p in me.polygons:
            ff.append(tuple(offset+i for i in p.vertices));smooth.append(p.use_smooth)
            for li in p.loop_indices:
                uvs.append(tuple(uv.data[li].uv) if uv else (0,0))
                colors.append(tuple(cc.data[li].color) if cc and cc.domain=='CORNER' else (1,1,1,1))
                normals.append(tuple((normal_matrix@me.corner_normals[li].vector).normalized()))
        offset+=len(me.vertices);ev.to_mesh_clear()
    me=bpy.data.meshes.new(name+'_Mesh');me.from_pydata(vv,[],ff);me.update();me.materials.append(objects[0].data.materials[0])
    uv=me.uv_layers.new(name='UVMap');uv.data.foreach_set('uv',[x for pair in uvs for x in pair])
    cc=me.color_attributes.new(name='Surface_Tint',type='FLOAT_COLOR',domain='CORNER');cc.data.foreach_set('color',[x for c in colors for x in c]);me.color_attributes.active_color=cc
    for p in me.polygons:p.use_smooth=True
    me.normals_split_custom_set(normals)
    o=bpy.data.objects.new(name,me);COLS['14_Runtime'].objects.link(o);o['role']='environment' if visible else 'collision'
    o['source_features']=json.dumps([x.name for x in objects]);o.hide_render=True;runtime.append(o);return o
groups={}
for (area,matname),objects in sorted(batches.items()):
    if area not in groups:
        g=bpy.data.objects.new('AREA_'+area,None);COLS['14_Runtime'].objects.link(g);g['role']='area';g['area']=area;groups[area]=g;runtime.append(g)
    o=combine('ENV_'+area+'_'+matname.split('|')[0].strip().replace(' ','_'),objects);o.parent=groups[area];o['area']=area
# One collision mesh per architectural area keeps the future loader's AABB candidate
# tests meaningful while the source's individual collider meshes remain editable.
coll_by_area=defaultdict(list)
for o in COLLIDERS:coll_by_area[o.get('area','Site')].append(o)
for area,objects in sorted(coll_by_area.items()):
    o=combine('COL_'+area,objects,False);o['area']=area
    o.parent=groups.get(area)


bpy.ops.object.select_all(action='DESELECT')
for o in runtime+PATHS+MARKERS:
    o.hide_set(False);o.hide_render=False;o.select_set(True)
output=repo/'dist/assets/levels/eastbank-school.glb'
output.parent.mkdir(parents=True,exist_ok=True)
bpy.ops.export_scene.gltf(filepath=str(output),export_format='GLB',use_selection=True,export_extras=True,export_yup=True,export_apply=True,export_texcoords=True,export_normals=True,export_materials='EXPORT',export_image_format='AUTO',export_cameras=False,export_lights=False,export_animations=False)
for o in runtime:o.hide_render=True;o.select_set(False)
print('Exported edited school level:',output)
