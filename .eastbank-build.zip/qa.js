import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/GLTFLoader.js';
import { Sky } from 'three/addons/Sky.js';
import { MeshoptDecoder } from '/dist/vendor/meshopt_decoder.module.js';
import { SkateWorld } from '/dist/src/skate/world.js';
import { parseGrindPaths } from '/dist/src/skate/rails.js';
const scene=new THREE.Scene();scene.fog=new THREE.Fog(0xb8c6c5,130,290);
const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
renderer.setSize(1440,900);renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.85;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.shadowMap.autoUpdate=false;
document.body.append(renderer.domElement);
const camera=new THREE.PerspectiveCamera(58,1.6,.06,350);
const sky=new Sky();sky.scale.setScalar(1500);
const u=sky.material.uniforms;u.turbidity.value=2.5;u.rayleigh.value=2;u.mieCoefficient.value=.003;u.mieDirectionalG.value=.77;
const dir=new THREE.Vector3(-.4,.73,-.56).normalize();u.sunPosition.value.copy(dir);scene.add(sky);
const pmrem=new THREE.PMREMGenerator(renderer);const envScene=new THREE.Scene();envScene.add(sky.clone());
const env=pmrem.fromScene(envScene,.035,.1,1800);scene.environment=env.texture;scene.environmentIntensity=.25;pmrem.dispose();
scene.add(new THREE.HemisphereLight(0xc0d7ed,0x786951,.48));
const sun=new THREE.DirectionalLight(0xffe6c4,2.1);sun.position.copy(dir).multiplyScalar(110);sun.castShadow=true;
sun.shadow.mapSize.set(4096,4096);Object.assign(sun.shadow.camera,{left:-90,right:90,top:90,bottom:-90,near:.5,far:245});
sun.shadow.normalBias=.035;sun.shadow.bias=-.00006;scene.add(sun,sun.target);
const loader=new GLTFLoader();loader.setMeshoptDecoder(MeshoptDecoder);
const gltf=await loader.loadAsync('/dist/assets/levels/eastbank-school.glb');scene.add(gltf.scene);gltf.scene.updateMatrixWorld(true);
const collision=[],paths=[],meshes=[];let triangles=0;
gltf.scene.traverse(o=>{if(o.userData.role==='grind_path')paths.push(o);if(!o.isMesh)return;
 if(o.userData.role==='collision'||o.name.startsWith('COL_')){collision.push(o);o.visible=false;return;}
 o.castShadow=o.receiveShadow=true;meshes.push(o);triangles+=(o.geometry.index?.count??o.geometry.attributes.position.count)/3;
});
const world=new SkateWorld(collision);const grindPaths=parseGrindPaths(paths);
const probeDefs=[['entrance',10,-47,0],['canteen',3,-28,.54],['academic',30,22,1.44],['upper',30,22,5.35],['library',4,28,2.16],['forum',-9,7,-.9],['basin',-43,22,-1.8],['court',-40,-10,.07],['dock',-44,33,.96]];
const probes=probeDefs.map(([name,x,by,height])=>{const fromY=name==='academic'?4:height+1.5;const hit=world.ground(x,-by,fromY,{},5);return {name,expected:height,actual:hit?.y,error:hit?Math.abs(hit.y-height):null};});
if(probes.some(p=>p.error===null||p.error>.025))throw new Error('Collision height mismatch: '+JSON.stringify(probes));
if(grindPaths.length!==189)throw new Error('Missing grind paths');
const curved=paths.find(p=>p.name==='PATH_RetentionBasin_Rim');if(curved.userData.points.length<600)throw new Error('Curved path sampling lost');
const textures=new Set();const mats=new Set();for(const mesh of meshes){for(const m of (Array.isArray(mesh.material)?mesh.material:[mesh.material])){mats.add(m);for(const k of ['map','normalMap','roughnessMap','metalnessMap'])if(m[k])textures.add(m[k]);}}
const textureSizes=[...textures].map(t=>({name:t.name,width:t.image?.width,height:t.image?.height}));
if(textureSizes.some(t=>t.width!==2048||t.height!==2048))throw new Error('Unexpected texture resolution');
const views={
 Overview:[[108,91,122],[0,1,-3],50],
 Library:[[ -27,10,8],[6,2.8,-27],58],
 Classroom:[[21,4.5,12],[31,4.1,-21],58],
 Basin:[[-22,10,2],[-45,1.5,-28],56],
 Canteen:[[21,7,9],[-11,2.4,33],58],
 EyeLevel:[[10,1.7,43],[4,2,-21],70]
};
window.qaReport={visibleTriangles:triangles,meshes:meshes.length,materials:mats.size,grindPaths:grindPaths.length,collisionMeshes:collision.length,probes,textureSizes,views:{},renderer:renderer.getContext().getParameter(renderer.getContext().RENDERER)};
window.captureSchool=async name=>{const [pos,target,fov]=views[name];camera.position.fromArray(pos);camera.fov=fov;camera.updateProjectionMatrix();camera.lookAt(new THREE.Vector3(...target));
 renderer.shadowMap.needsUpdate=!window.schoolShadowReady;renderer.render(scene,camera);window.schoolShadowReady=true;
 await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
 window.qaReport.views[name]={triangles:renderer.info.render.triangles,drawCalls:renderer.info.render.calls,textures:renderer.info.memory.textures};return window.qaReport.views[name];};
await window.captureSchool('Overview');window.schoolReady=true;
