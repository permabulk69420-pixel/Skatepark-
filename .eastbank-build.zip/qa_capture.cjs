const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch({headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
 const page=await b.newPage({viewport:{width:1440,height:900}});const errors=[];let failPage;const pageFailed=new Promise((_,reject)=>{failPage=reject});pageFailed.catch(()=>{});page.on('pageerror',e=>{errors.push(e.message);console.error('PAGE_ERROR',e.stack||e.message);failPage(e)});
 page.on('console',m=>{if(m.type()==='error')console.log('CONSOLE',m.text())});
 await page.goto('http://127.0.0.1:8080/incoming-school/qa.html',{timeout:120000});
 await Promise.race([page.waitForFunction(()=>window.schoolReady,undefined,{timeout:180000}),pageFailed]);fs.mkdirSync('school-qa',{recursive:true});
 for(const name of ['Overview','Library','Classroom','Basin','Canteen','EyeLevel']){
  await page.evaluate(n=>window.captureSchool(n),name);await page.screenshot({path:'school-qa/'+name+'.png',timeout:120000});console.log('CAPTURED',name);
 }
 const report=await page.evaluate(()=>window.qaReport);report.errors=errors;fs.writeFileSync('school-qa/statistics.json',JSON.stringify(report,null,2));
 await b.close();if(errors.length)throw new Error(JSON.stringify(errors));console.log(JSON.stringify(report));
})();
