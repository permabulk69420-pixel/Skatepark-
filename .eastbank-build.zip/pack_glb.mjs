import { NodeIO } from './gltf-tools/node_modules/@gltf-transform/core/dist/index.js';
import { ALL_EXTENSIONS, EXTMeshoptCompression } from './gltf-tools/node_modules/@gltf-transform/extensions/dist/index.js';
import { weld, reorder } from './gltf-tools/node_modules/@gltf-transform/functions/dist/index.js';
import { MeshoptEncoder, MeshoptDecoder } from './gltf-tools/node_modules/meshoptimizer/index.module.js';
import fs from 'node:fs';

// Lossless vertex/index compression. No quantisation, simplification, texture
// resizing, LOD changes or rendering settings. Original JPEG maps are preserved.
await MeshoptEncoder.ready;await MeshoptDecoder.ready;
const io=new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({'meshopt.encoder':MeshoptEncoder,'meshopt.decoder':MeshoptDecoder});
const src=process.argv[2],dest=process.argv[3];
const doc=await io.read(src);
const triangleCount=d=>d.getRoot().listMeshes().reduce((n,m)=>n+m.listPrimitives().reduce((v,p)=>v+(p.getIndices()?.getCount()??p.getAttribute('POSITION').getCount())/3,0),0);
const before=triangleCount(doc);
// Blender's colour conversion may round white slightly above 1. Correct the
// glTF colour range without changing geometry or reducing texture precision.
for(const mesh of doc.getRoot().listMeshes())for(const p of mesh.listPrimitives()){
 const attr=p.getAttribute('COLOR_0');if(!attr)continue;const a=attr.getArray();
 for(let i=0;i<a.length;i++)a[i]=Math.max(0,Math.min(1,a[i]));attr.setArray(a);
}
await doc.transform(weld({tolerance:0}),reorder({encoder:MeshoptEncoder,target:'size'}));
doc.createExtension(EXTMeshoptCompression).setRequired(true).setEncoderOptions({method:EXTMeshoptCompression.EncoderMethod.QUANTIZE});
await io.write(dest,doc);
const decoded=await io.read(dest);const after=triangleCount(decoded);
if(before!==after)throw new Error(`Triangle count changed ${before} -> ${after}`);
const report={trianglesBefore:before,trianglesAfter:after,bytes:fs.statSync(dest).size,meshes:decoded.getRoot().listMeshes().length,materials:decoded.getRoot().listMaterials().length,textures:decoded.getRoot().listTextures().length,positionComponents:[...new Set(decoded.getRoot().listMeshes().flatMap(m=>m.listPrimitives().map(p=>p.getAttribute('POSITION').getComponentType())))]};
console.log(JSON.stringify(report,null,2));fs.writeFileSync(dest+'.stats.json',JSON.stringify(report,null,2));
